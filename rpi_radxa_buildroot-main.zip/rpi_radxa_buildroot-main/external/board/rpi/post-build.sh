#!/bin/bash

set -u
set -e

source ${BR2_EXTERNAL_AA_PROXY_OS_PATH}/board/common/post-build.sh
source ${BR2_EXTERNAL_AA_PROXY_OS_PATH}/board/common/add_tty1.sh
